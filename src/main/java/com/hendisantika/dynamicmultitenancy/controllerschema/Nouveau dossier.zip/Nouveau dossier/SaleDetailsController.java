package com.hendisantika.dynamicmultitenancy.controllerschema;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hendisantika.dynamicmultitenancy.controller.AuthenticationController;
import com.hendisantika.dynamicmultitenancy.tenant.entity.*;
import com.hendisantika.dynamicmultitenancy.tenant.repository.*;




@RestController
@RequestMapping("/api/SalesDetails")
public class SaleDetailsController implements Serializable{

	private static final long serialVersionUID = 1L;
    private static final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);

    
    @Autowired
    private SaleDetailsRepository saleDetailsRepository;
    
    
    @GetMapping("/all")
	public ResponseEntity<Object> getAllSaleDetails(){
		
		try {
			Iterable<SaleDetails> SaleDetails = saleDetailsRepository.findAll();
			return new ResponseEntity<Object>(SaleDetails, HttpStatus.OK);
		} catch(Exception ex) {
			logger.error(ex.getMessage(), ex);
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
		}
	}
    
    
    @GetMapping("/by/{id}")
	public ResponseEntity<Object> getSaleDetailsById(@PathVariable("id") Long id) {
		try {
			SaleDetails saleDetails = saleDetailsRepository.findById(id).get();
			if(saleDetails != null) {
				return new ResponseEntity<Object>(saleDetails, HttpStatus.OK);				
			} else {
				return new ResponseEntity<Object>(HttpStatus.NOT_FOUND);
			}
		} catch(Exception ex) {
			logger.error(ex.getMessage(), ex);
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
		}
	}
    
    @PostMapping("/create")
	public ResponseEntity<Object> createSaleDetails(@RequestBody SaleDetails saleDetails) {
		try {   
			SaleDetails savedSaleDetails = saleDetailsRepository.save(saleDetails);
			return new ResponseEntity<Object>(savedSaleDetails, HttpStatus.OK);
		} catch(Exception ex) {
			logger.error(ex.getMessage(), ex);
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
		}
	}
    
    @PutMapping("/update/{id}")
	public ResponseEntity<Object> updateSaleDetails(@PathVariable("id") Long id, @RequestBody SaleDetails saleDetails) {
		try {
			saleDetails.setId(id);
			SaleDetails savedSaleDetails = saleDetailsRepository.save(saleDetails);
			return new ResponseEntity<Object>(savedSaleDetails , HttpStatus.OK);
		} catch(Exception ex) {
			logger.error(ex.getMessage(), ex);
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
		}
	}
    
    @DeleteMapping("/delete/{id}")
	public ResponseEntity<HttpStatus> deleteSaleDetails(@PathVariable("id") Long id) {
		try {
			saleDetailsRepository.deleteById(id);
			return new ResponseEntity<HttpStatus>(HttpStatus.OK);
		} catch(Exception ex) {
			logger.error(ex.getMessage(), ex);
			return new ResponseEntity<HttpStatus>(HttpStatus.BAD_REQUEST);
		}
	}
}
