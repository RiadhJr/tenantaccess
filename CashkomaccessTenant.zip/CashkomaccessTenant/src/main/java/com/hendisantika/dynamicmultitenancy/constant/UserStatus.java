package com.hendisantika.dynamicmultitenancy.constant;

/**
 * Created by IntelliJ IDEA.
 * Project : springboot-security-jwt-rest-api-dynamic-multi-tenancy-mysql-postgresql
 * User: hendisantika
 * Email: hendisantika@gmail.com
 * Telegram : @hendisantika34
 * Date: 08/05/20
 * Time: 05.37
 */
public enum UserStatus {
    ACTIVE, INACTIVE
}