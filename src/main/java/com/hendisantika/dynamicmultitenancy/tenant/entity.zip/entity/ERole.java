package com.hendisantika.dynamicmultitenancy.tenant.entity;

public enum ERole {
  ROLE_SUPERUSER,
  ROLE_PUBLISHER,
  ROLE_TENANT
}
