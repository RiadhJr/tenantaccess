package com.hendisantika.dynamicmultitenancy.tenant.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "tbl_produit")
public class Produit {

	
	@Id
    @Column(name = "produit_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long produit_id;
	
	@Column(name = "photo")
    private String photo;
	
	@Column(name = "ref_produit ")
    private String refproduit;
	
	@Column(name = "prix_unitaire")
    private Double prixunitaire;
	
	@Column(name = "prix_gros")
    private Double prix_gros;
	
	@Column(name = "date_entre")
    private Date  dateentre;
	
	@Column(name = "date_sortie")
    private Date  datesortie;
	
	@Column(name = "quantite_initial")
    private Long  quantiteinitial;
	
	@Column(name = "quantite_ajouter")
    private Long  quantiteajouter;
	
    @NotFound(action = NotFoundAction.IGNORE)
	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "categorie_id", nullable = true)
    private Categorie categorie;
    
    @NotFound(action = NotFoundAction.IGNORE)
	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "fournisseur_id", nullable = true)
    private Fournisseur fournisseur;

	public Long getProduit_id() {
		return produit_id;
	}

	public void setProduit_id(Long produit_id) {
		this.produit_id = produit_id;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getRefproduit() {
		return refproduit;
	}

	public void setRefproduit(String refproduit) {
		this.refproduit = refproduit;
	}

	public Double getPrixunitaire() {
		return prixunitaire;
	}

	public void setPrixunitaire(Double prixunitaire) {
		this.prixunitaire = prixunitaire;
	}

	public Double getPrix_gros() {
		return prix_gros;
	}

	public void setPrix_gros(Double prix_gros) {
		this.prix_gros = prix_gros;
	}

	public Date getDateentre() {
		return dateentre;
	}

	public void setDateentre(Date dateentre) {
		this.dateentre = dateentre;
	}

	public Date getDatesortie() {
		return datesortie;
	}

	public void setDatesortie(Date datesortie) {
		this.datesortie = datesortie;
	}

	public Long getQuantiteinitial() {
		return quantiteinitial;
	}

	public void setQuantiteinitial(Long quantiteinitial) {
		this.quantiteinitial = quantiteinitial;
	}

	public Long getQuantiteajouter() {
		return quantiteajouter;
	}

	public void setQuantiteajouter(Long quantiteajouter) {
		this.quantiteajouter = quantiteajouter;
	}

	public Categorie getCategorie() {
		return categorie;
	}

	public void setCategorie(Categorie categorie) {
		this.categorie = categorie;
	}

	public Fournisseur getFournisseur() {
		return fournisseur;
	}

	public void setFournisseur(Fournisseur fournisseur) {
		this.fournisseur = fournisseur;
	}
    
    
	
	

	
}