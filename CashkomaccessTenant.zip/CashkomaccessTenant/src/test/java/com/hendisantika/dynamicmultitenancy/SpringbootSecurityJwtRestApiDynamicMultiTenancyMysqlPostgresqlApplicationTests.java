package com.hendisantika.dynamicmultitenancy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSecurityJwtRestApiDynamicMultiTenancyMysqlPostgresqlApplicationTests {

    @Test
    void contextLoads() {
    }

}
